soft name: CH341A Programmer
Copyright: Maple Online Http://SkyGz.Taobao.com
Author: SkyGz(Campanula night Siyu)
Email: SkyGz@QQ.CoM

Introduction: support 24/25 series chip read and write.
CH341A.EXE	To be registered with the full functional version
CH341AFREE.EXE	Free registration the ordinary version

To view the latest information, please visit http://blog.163.com/skygz@126/
Genuine users can ask for registration code.

The functional limitations are as follows:
1.Every time the run will pop up to the window to be registered.
2.Detection function is not available.
3.Fill function is not available.
3.Chip Search function is not available.
4.Can not burn less than 1M and more than 8M chips.